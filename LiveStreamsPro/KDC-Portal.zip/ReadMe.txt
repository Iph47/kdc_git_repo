"YOU" have to 


--- download and install the following script.modules first:---

script.module.limitless-swiftstreamz
script.module.limitless-tvtap
script.module.7of9-motherless
script.module.7of9-videodevil
script.module.7of9-pirateslife4me
script.module.moss

download the Kodi-Deutschland-Community.xml 
kick it on your kodi system in this folder:

/storage/.kodi/userdata/playlists/video

and open in livestreamspro addon options / add source / choose source type (choose file insteet of url!!!)
then choose the copied file source:
/storage/.kodi/userdata/playlists/video/Kodi_Deutschland_Community.xml. 



have4un!
