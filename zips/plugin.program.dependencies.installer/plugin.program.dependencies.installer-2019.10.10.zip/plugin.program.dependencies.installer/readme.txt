Mit diesem Addon kann von jedem beliebigem Github ein Update geladen werden

Die Addons sind in der data.txt einzutragen, so wie die beiden Beispiele (URLResolver und Joyn)

Die erste schreibweise (URLResolver) ist für private Github Repo Branchen, die zweite Schreibweise für ein öffentliches Github (Joyn)

Unter resources/images/ werden die dazugehörigen Icons abgelegt. Diese werde dann im Addon Menü angezeigt und sind erforderlich

Anwendung des Addons:

Addon starten
Wählen was aktualisiert werden soll
Klicken und warten bis die Meldung kommt: 

- Write New data (mit Addon ID und Version)

Dann war das update erfolgreich