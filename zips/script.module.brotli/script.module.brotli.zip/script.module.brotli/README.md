# script.module.brotli

Python brotli library packed for Kodi.

See https://github.com/google/brotli