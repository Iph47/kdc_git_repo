# script.module.requests_toolbelt

Python requests_toolbelt library packed for Kodi

See https://github.com/requests/toolbelt