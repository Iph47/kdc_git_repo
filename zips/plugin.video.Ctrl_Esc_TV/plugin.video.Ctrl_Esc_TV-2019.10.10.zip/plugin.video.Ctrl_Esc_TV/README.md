![Control Escape TV](icon.png)

You need the missing "video.json" to complete the mission!

