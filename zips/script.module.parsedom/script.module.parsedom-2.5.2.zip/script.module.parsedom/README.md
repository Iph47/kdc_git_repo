![Mutagen](icon.png)

Kodi module containing [Parsedom](https://pypi.org/project/parsedom/).
